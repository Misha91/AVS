/**
 ******************************************************************************
 * @file    main.c
 * @author  MCD Application Team
 * @version V1.1.0
 * @date    07-October-2011
 * @brief   Main program body
 ******************************************************************************
 * @attention
 *
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
 * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
 * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
 * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
 * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>

#include "stm32_eval.h"
#include "../SC-IDE/lcd.h"
#define POINTS 500
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define LCD_MAX_CHARS (int)(LCD_PIXEL_WIDTH/ LCD_FONT_WIDTH)
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void delay(vu32 nCount);
void updateAcc(int* xVal, int* yVal);
void drawWorld(uint8_t* world);
void lcdClearCircle(uint64_t x, uint64_t y, uint8_t* world);
void lcdDrawCircle(uint64_t x, uint64_t y, uint8_t* world);
/* Private functions ---------------------------------------------------------*/

/**
 * Main program.
 * @return Nothing.
 */
int main(void) {
    char sTmp[LCD_MAX_CHARS];
    uint8_t world[8][128];
    uint8_t last, mult;
    int32_t lastX, lastY;
    last = -1;
    mult = 40;
    lastX = -1;
    lastY = -1;
    /* Accelerometer initialization */
    sACCEL_Init();
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_StructInit(&GPIO_InitStructure);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    //GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    //GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /* LCD initialization */
    LCD_Init();
    LCD_SetBacklight(100);
    LCD_DisplayStringLine(Line0, "Hello.");
    
    //
    uint32_t k = 0;
    uint8_t i, j;
    
    for (i = 0; i < 8; i++){
        for (j = 0; j < 128; j++){
            if ((j == 64 || j == 65) && (i > 0 && i < 7) ) world[i][j] = 0xFF;
            else if (i == 3 && (j>15 && j < 115) ) world[i][j] = 0xC0;
            else world[i][j] = 0x00;
        }
    }
    
    sACCEL_ReadReg(0x0F);    
    sACCEL_WriteReg(0x20, 0x87);
    sACCEL_WriteReg(0x21, 0x80);
    
    ComPort_Init(COM2);
     ComPort_ConfigStdio(COM2, COM2, COM2);

    int xVal = 0;
    int yVal = 0;
    int xLastChange = 0;
    int yLastChange = 0;
    uint16_t x_shift = 0; //60
    uint16_t y_shift = 0; //28    
    y_shift = (y_shift - 1);
    y_shift /=2;
    x_shift = y_shift; 
    drawWorld(world);

    while (1) {
       
        updateAcc(&xVal, &yVal);
        
        int16_t tmpX = ((xVal * mult)>>1);
        int16_t tmpY = yVal * mult;
        int tmpRes = x_shift + xLastChange + ((tmpX > 300) ? (tmpX - 150) : ((tmpX < -300) ? (tmpX + 150) : 0));
        x_shift = tmpRes < 0 ? 0 : (tmpRes > 62000 ? 62000 : tmpRes);
        
        tmpRes = y_shift + yLastChange + ((tmpY > 300) ? (tmpY - 150) : ((tmpY < -300) ? (tmpY + 150) : 0));
        y_shift = tmpRes < 0 ? 0 : (tmpRes > 55000 ? 55000 : tmpRes);

        xLastChange = (x_shift - lastX)>>1;    
        yLastChange = (y_shift - lastY)>>1;
        
        if (lastX != x_shift || lastY != y_shift){
            
            uint8_t lX = lastX/500;
            uint8_t lY = lastY/1000;
            uint8_t nX = x_shift/500;
            uint8_t nY = y_shift/1000;
            int16_t chX = nX - lX;
            int16_t chY = nY - lY;
            char canGo = 1;
            char canGoX = 1;
            char canGoY = 1;
            
            //if (chX > 0) lX -= 4;
            int8_t steps_to_go = abs(chX) > abs(chY) ? abs(chX) : abs(chY);
            
            //steps_to_go *= 2;
            float incX = (chX / steps_to_go);
            float incY = (chY / steps_to_go);
            float tmpX = lX;
            float tmpY = lY;
            //if (chX > 0) tmpX += 3;
            //else tmpX += 2;
            //iprintf("%d %d\n", lX, nX, lY, nY);
            //iprintf("%2.3f %2.3f\n", incX, incY);
           // if ((world[((int)tmpY)/8][(int)tmpX] & 0x0F<<((int)tmpY)%8) | (world[((int)tmpY)/8+1][(int)tmpX] & 0x0F>>(8-((int)tmpY)%8))) canGo = 1;
            while(canGo){
                //iprintf("%d %d %d %d, %d %d %d %d\n", abs((int)tmpX - lX), (int)tmpX, lX, abs(chX), abs((int)tmpY - lY), (int)tmpY, lY, abs(chY));
                if (canGoX == 1){
                    if (chX > 0) tmpX += incX;
                    else tmpX -= incX;
                    uint8_t y = (int)tmpY / 8;
                    uint8_t k = y % 8;
                    //iprintf("X%d\n", world[y][(int)tmpX] & 0x0F<<k);
                    //iprintf("X%d\n", world[y+1][(int)tmpX] & 0x0F>>(8-k));
                    if ((world[y][(int)tmpX] & 0x0F<<k) | (world[y+1][(int)tmpX] & 0x0F>>(8-k))){
                        iprintf("CANT GO X\n");
                        canGoX = 0;
                        xLastChange = 0;
                        if (chX > 0) tmpX = (int)tmpX - 1;
                        else tmpX = (int)tmpX + 1;
                    }
                }
                
                if (canGoY){
                    if (chY > 0) tmpY += incY;
                    else tmpY -= incY;
                    //iprintf(world[(int)tmpX][(int)tmpY] & 0x0F);
                    uint8_t y = (int)tmpY / 8;
                    uint8_t k = y % 8;
                    //iprintf("Y%d\n", world[y][(int)tmpX] & 0x0F<<k);
                    //iprintf("Y%d\n", world[y+1][(int)tmpX] & 0x0F>>(8-k));
                    if ((world[y][(int)tmpX] & 0x0F<<k) | (world[y+1][(int)tmpX] & 0x0F>>(8-k))){
                        canGoY = 0;
                        yLastChange = 0;
                        iprintf("CANT GO Y\n");
                        if (chY > 0) tmpY = (int)tmpY - 1;
                        else tmpY = (int)tmpY + 1;
                    }
                }
                
                if ((canGoX == 0 || canGoY == 0) || (abs((int)tmpX - lX) >= abs(chX) || abs((int)tmpY - lY) >= abs(chY))){
                    canGo = 0;
                    break;
                }
                
            }        
            
            
            //else y_shift = lastY;
            //if 
            //else{
            //if (1){
            
            //if (chX > 0) tmpX += 4;
            if (canGoX == 0){
                //if (chX > 0) tmpX -= 3;
                //else tmpX -= 2;
                //if (chX < 0) tmpX += 2;
                iprintf("CGX: %d %d %d\n", lastX, x_shift, (int)tmpX*500);
                x_shift = (int)tmpX*500;
                //lastX = x_shift; 
            }
            
            if (canGoY == 0) {
                iprintf("CGY: %d %d %d\n", lastY, y_shift, (int)tmpY*1000);
                y_shift = (int)tmpY*1000;
            }
            
            
            
            
            
            if ((int)lastX/500 != (int)x_shift/500 || (int)lastY/1000 != (int)y_shift/1000){
                lcdClearCircle((int)lastX/500, (int)lastY/1000, world);
                snprintf(sTmp, LCD_MAX_CHARS, "%.3f %.3f %d %d %d %d", incX, incY, lX, nX, lY, nY);
                LCD_ClearLine(Line7);
                LCD_DisplayStringLine(Line7, sTmp); 
                lcdDrawCircle((int)x_shift/500, (int)y_shift/1000, world); 
            }
            lastX = x_shift; 
            lastY = y_shift;
            //}
            //lastY *= 1000;
            
            
//            if (world[(int)y_shift/8000][(int)x_shift/500]){
//                if (world[(int)lastX/8000][(int)x_shift/500]) {
//                    lastX = x_shift; 
//                    y_shift = lastY;
//                }
//                else if (world[(int)y_shift/8000][(int)lastX/500]) {
//                    x_shift = lastX;
//                    lastY = y_shift;
//                }
//                else{
//                    x_shift = lastX;
//                    y_shift = lastY;
//                }
//            }
//            else{
//                lastX = x_shift; 
//                lastY = y_shift;
//            }
            
        }
        
        uint8_t bt2 = GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_14);   
        
        if ((bt2 == 0) ){
            if (last != 51){
                last = 1;
                LCD_Clear();
                snprintf(sTmp, LCD_MAX_CHARS, "%d %d", x_shift, y_shift);
                LCD_DisplayStringLine(Line0, sTmp); 
                snprintf(sTmp, LCD_MAX_CHARS, "%d %d", (int)x_shift/500, (int)y_shift/8000);
                LCD_DisplayStringLine(Line1, sTmp);     
                snprintf(sTmp, LCD_MAX_CHARS, "%d %d", (int)x_shift/500, (int)y_shift/1000);
                LCD_DisplayStringLine(Line2, sTmp); 
                snprintf(sTmp, LCD_MAX_CHARS, "%d %d", lastX, lastY);
                LCD_DisplayStringLine(Line3, sTmp); 
                snprintf(sTmp, LCD_MAX_CHARS, "%d %d", xLastChange, yLastChange);
                LCD_DisplayStringLine(Line4, sTmp); 
                snprintf(sTmp, LCD_MAX_CHARS, "%d %d", tmpRes, tmpX);
                LCD_DisplayStringLine(Line5, sTmp); 
            }
        }        
        else if ((bt2 == 1) && (last != 0) ){
            last = 0; 
            LCD_Clear();
            drawWorld(world);
            lcdDrawCircle((int)lastX/500, (int)lastY/1000, world);
        }
        

        delay(0xFFFFF);
    }      
}

/**
 * Delay function
 * @param nCount = Number of cycles to delay.
 */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/


void lcdDrawCircle(uint64_t x, uint64_t y, uint8_t* world){
   
    uint8_t k = y % 8;
    y = y/8;   
   
    
    if (y <= 6){
        LCD_WriteTo(y, x,0x06<<k | *(world + (y*128) + x));
        LCD_WriteTo(y+1, x,0x06>>(8-k) | *(world + ((y+1)*128) + x));
        LCD_WriteTo(y,  x+1,  0x0F<<k | *(world + (y*128) + x + 1));
        LCD_WriteTo(y+1, x+1,0x0F>>(8-k) | *(world + ((y+1)*128) + x + 1));
        LCD_WriteTo(y, x+2,0x0F<<k | *(world + (y*128) + x + 2));
        LCD_WriteTo(y+1, x+2,0x0F>>(8-k) | *(world + ((y+1)*128) + x + 2));
        LCD_WriteTo(y, x+3,0x06<<k | *(world + (y*128) + x + 3));
        LCD_WriteTo(y+1, x+3,0x06>>(8-k) | *(world + ((y+1)*128) + x + 3));
    }
  
    //LCD_DrawYLine(64, 1, 0, 7);
}

void lcdClearCircle(uint64_t x, uint64_t y, uint8_t* world){
    
    uint8_t k = y % 8;
    y = y/8;
       

    if (y <= 6){
        LCD_WriteTo(y, x,0x00<<k | *(world + (y*128) + x));
        LCD_WriteTo(y+1, x,0x00>>(8-k) | *(world + ((y+1)*128) + x));
        LCD_WriteTo(y,  x+1,  0x00<<k | *(world + (y*128) + x + 1));
        LCD_WriteTo(y+1, x+1,0x00>>(8-k) | *(world + ((y+1)*128) + x + 1));
        LCD_WriteTo(y, x+2,0x00<<k | *(world + (y*128) + x + 2));
        LCD_WriteTo(y+1, x+2,0x00>>(8-k)  | *(world + ((y+1)*128) + x + 2));
        LCD_WriteTo(y, x+3,0x00<<k | *(world + (y*128) + x + 3));
        LCD_WriteTo(y+1, x+3,0x00>>(8-k) | *(world + ((y+1)*128) + x + 3));
    }
  
    //LCD_DrawYLine(64, 1, 0, 7);
}

void drawWorld(uint8_t* world){
    uint8_t i, j;
    
    for (i = 0; i < 8; i++){
        for (j = 0; j < 128; j++){
            if (*(world + i*128 + j)) LCD_WriteTo(i, j, *(world + i*128 + j));
        }
    }
}

void updateAcc(int* xVal, int* yVal){

    uint8_t xL = sACCEL_ReadReg(0x28);        
    uint8_t xH = sACCEL_ReadReg(0x29);      
    uint8_t yL = sACCEL_ReadReg(0x2A);        
    uint8_t yH = sACCEL_ReadReg(0x2B);  


     if (xH >= 0x00 && xH < 0x08){
             *xVal = (int)(xH * 256 + xL);
     }
     else if (xH <= 0xFF && xH > 0xFB){
             *xVal = - (int)((0xFF-xH) * 256 + (0xFF-xL));
     }
     if (yH >= 0x00 && yH < 0x08){
         *yVal = -(int)(yH * 256 + yL);
     }
     else if (yH <= 0xFF && yH > 0xFB){
         *yVal = (int)((0xFF-yH) * 256 + (0xFF-yL));
     }
}